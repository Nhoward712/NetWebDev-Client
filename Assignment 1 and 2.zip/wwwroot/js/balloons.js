﻿$(function () {
    $('#birthday').pickadate({ format: 'mmmm, d' });

});